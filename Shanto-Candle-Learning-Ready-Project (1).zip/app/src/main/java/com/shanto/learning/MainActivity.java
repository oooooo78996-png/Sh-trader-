package com.shanto.learning;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import android.text.InputType;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText[][] values = new EditText[3][4];
    private TextView result, details, history, stats;
    private int analyses = 0;

    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private void space(LinearLayout box, int h) {
        TextView v = new TextView(this); v.setHeight(dp(h)); box.addView(v);
    }
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(24));
        root.setBackgroundColor(Color.rgb(14, 20, 30));
        scroll.addView(root);

        TextView title = label("SHANTO AI TRADER", 24, Color.rgb(0, 230, 145));
        title.setGravity(Gravity.CENTER); root.addView(title);
        TextView sub = label("CANDLE LEARNING • PAPER PRACTICE", 12, Color.LTGRAY);
        sub.setGravity(Gravity.CENTER); root.addView(sub);
        space(root, 14);

        TextView notice = label("শুধু শিক্ষামূলক অনুশীলন। এটি Quotex-এর live data পড়ে না, ট্রেডিং signal দেয় না এবং real-money decision-এর জন্য নয়।", 14, Color.YELLOW);
        root.addView(notice); space(root, 12);

        root.addView(label("Practice market (শুধু লেবেল)", 15, Color.WHITE));
        Spinner market = new Spinner(this);
        String[] markets = {"Regular — Demo label", "OTC — Demo label"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, markets);
        market.setAdapter(adapter); root.addView(market);

        root.addView(label("Practice timeframe", 15, Color.WHITE));
        Spinner timeframe = new Spinner(this);
        timeframe.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"30 seconds — practice only"}));
        root.addView(timeframe);
        space(root, 10);

        String[] names = {"Open", "High", "Low", "Close"};
        for (int r=0; r<3; r++) {
            root.addView(label("Candle " + (r+1) + " (পুরোনো থেকে নতুন)", 15, Color.WHITE));
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            for (int c=0; c<4; c++) {
                LinearLayout cell = new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL);
                cell.setPadding(dp(3), 0, dp(3), 0);
                cell.addView(label(names[c], 11, Color.LTGRAY));
                EditText e = new EditText(this); e.setSingleLine(true); e.setTextSize(14);
                e.setTextColor(Color.WHITE); e.setHint("0.00");
                e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
                values[r][c] = e;
                cell.addView(e, new LinearLayout.LayoutParams(-1, -2));
                row.addView(cell, new LinearLayout.LayoutParams(0, -2, 1));
            }
            root.addView(row); space(root, 5);
        }

        Button analyze = new Button(this); analyze.setText("ANALYZE PRACTICE CANDLES");
        root.addView(analyze);
        result = label("ফলাফল এখানে দেখাবে", 19, Color.WHITE); space(root, 10); root.addView(result);
        details = label("", 14, Color.LTGRAY); root.addView(details);
        space(root, 16);
        stats = label("Practice analyses completed: 0", 14, Color.rgb(0, 220, 145)); root.addView(stats);
        history = label("Practice history: এখনো কোনো analysis হয়নি।", 13, Color.LTGRAY); root.addView(history);

        analyze.setOnClickListener(v -> runAnalysis());
        setContentView(scroll);
    }

    private void runAnalysis() {
        try {
            double[][] a = new double[3][4];
            for (int r=0; r<3; r++) for (int c=0; c<4; c++) {
                String s = values[r][c].getText().toString().trim();
                if (s.isEmpty()) throw new Exception("সব ১২টি ঘরে Open, High, Low, Close লিখুন।");
                a[r][c] = Double.parseDouble(s);
            }
            for (int r=0; r<3; r++) {
                double o=a[r][0], h=a[r][1], l=a[r][2], c=a[r][3];
                if (h < l || h < Math.max(o,c) || l > Math.min(o,c))
                    throw new Exception("Candle " + (r+1) + ": High/Low মান সঠিক নয়।");
            }
            int bull=0, bear=0;
            for (int r=0; r<3; r++) {
                if (a[r][3] > a[r][0]) bull++;
                else if (a[r][3] < a[r][0]) bear++;
            }
            double range=a[2][1]-a[2][2], body=Math.abs(a[2][3]-a[2][0]);
            String classification = bull>bear ? "বেশি bullish candle" :
                    bear>bull ? "বেশি bearish candle" : "মিশ্র / অস্পষ্ট candle";
            String bodyText = range==0 ? "শেষ candle-এর range শূন্য।" :
                    (body/range >= .6 ? "শেষ candle-এর body তার range-এর তুলনায় বড়।" :
                     "শেষ candle-এর body তার range-এর তুলনায় ছোট বা মাঝারি।");
            String movement = a[2][3]>a[0][3] ? "তিনটি close-এর প্রথম থেকে শেষ পর্যন্ত মান বেড়েছে।" :
                    a[2][3]<a[0][3] ? "তিনটি close-এর প্রথম থেকে শেষ পর্যন্ত মান কমেছে।" :
                    "প্রথম ও শেষ close একই।";
            analyses++;
            result.setText("শিক্ষামূলক পর্যবেক্ষণ: " + classification);
            details.setText(bodyText + "\n" + movement +
                "\n\nএটি কেবল দেওয়া ৩টি candle-এর বর্ণনা। ভবিষ্যৎ price movement, entry, payout, OTC/Regular live market বা পরের candle অনুমান করে না।");
            stats.setText("Practice analyses completed: " + analyses);
            String item = "• " + classification + " | " + marketName() + "\n";
            history.setText(item + history.getText().toString().replace("Practice history: এখনো কোনো analysis হয়নি.\n",""));
        } catch (Exception ex) {
            result.setText("Analysis করা যায়নি");
            details.setText(ex.getMessage()==null ? "সঠিক সংখ্যা লিখুন।" : ex.getMessage());
        }
    }
    private String marketName() { return "selected demo market"; }
}
